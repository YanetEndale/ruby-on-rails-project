# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TestSite::Application.config.secret_token = '8cd67da1cb5fff30dcb6c0f2543310c63c3959e6b0cd33c05ff6b97c269c112d76deaf52a56817d9e3ec1c457b514b8018ddeb989505c31864aac9b6c3d92b30'
