== Rails CRUD training app

This app is used to walk new developers through the basic Rails plumbing, MVC concepts, and flow.

== Setup

Copy the `config/database.yml.example` to `config/database.yml`
